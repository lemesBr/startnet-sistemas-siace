Notas sobre CUB32.DLL
---------------------

Para a dll funcionar ela tem que estar em algum dos seguintes diret�rios:
- Mesmo diret�rio do execut�vel que est� usando a dll
- Qualquier diret�rio do path.

Eu recomendo que seja colocada no diretorio do execut�vel, para evitar que existam v�rias
vers�es na mesma m�quina, e para facilitar o proceso de instala��o.