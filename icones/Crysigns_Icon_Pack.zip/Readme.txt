These icons should onle by used for non-commercial purposes.

There are 25 icons in total available in PNG format (256x256).
The icons look pretty good in both the sizes.


Author  : Asher (aka edesigner)
Website : kyo-tux.deviantart.com , igloo.crystalxp.net/ASHAR
