||                                                 ||
 ===================================================
        ____   ____                ___
       /   /  /   /               /  /
      /   /__/   /               /  /
     /          / ___  ___  ____/  / ______  ______
    /   ___    / /  / /  / / __   / /  ___/ / __  /
   /   /  /   / /  /_/  / / /_/  / /  /    / /_/ /
  /___/  /___/ /____   / /______/ /__/    /_____/
  _________________/  / ____  ___  ____        _
 /                   / /   / / _/ /   /   /\/\|_)
/___________________/ / __/ /_/  /___/
                     /_/

 ===================================================
||                                                 ||
||                 DOCK ICONS BY                   ||
||                  BEN FLEMING                    ||
||                                                 ||
||                     VISIT                       ||
||           mediadesign.deviantart.com            ||
||                   FOR  MORE                     ||
||                                                 ||
 ===================================================

Remember, every single icon is free for use in any way; this includes commercially!

Finally, http://mediadesign.deviantart.com is my homepage. Feel free to visit any time and check out my wide range of work if you've gotten tired of my icons.